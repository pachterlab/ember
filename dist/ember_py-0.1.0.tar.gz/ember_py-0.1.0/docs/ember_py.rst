ember\_py package
=================

Submodules
----------


ember\_py.light\_ember module
-----------------------------

.. automodule:: ember_py.light_ember
   :members:
   :show-inheritance:
   :undoc-members:
   
ember\_py.generate\_pvals module
--------------------------------

.. automodule:: ember_py.generate_pvals
   :members:
   :show-inheritance:
   :undoc-members:


ember\_py.plots module
----------------------

.. automodule:: ember_py.plots
   :members:
   :show-inheritance:
   :undoc-members:


ember\_py.top\_genes module
---------------------------

.. automodule:: ember_py.top_genes
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: ember_py
   :members:
   :show-inheritance:
   :undoc-members:
